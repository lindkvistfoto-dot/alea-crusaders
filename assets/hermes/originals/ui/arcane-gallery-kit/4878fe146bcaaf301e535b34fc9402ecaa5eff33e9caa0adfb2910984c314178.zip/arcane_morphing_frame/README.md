# ALEA CRUSADERS — ARCANE MORPHING FRAME

**Assetpaket v0.1 — proof of concept**, 16 oktober 2026.

## Innehåll

- 29 PNG-bilder med alfakanal. Bilderna är enskilda exporterade grafikobjekt, inklusive 6 extra delbilder för teleskopiska sidostycken.
- `manifest.json` beskriver varje fil, bildstorlek, utsnitt och ungefärlig pivotpunkt.
- `demo.html` är en interaktiv fristående prototyp med höjdanpassning och roterande kugghjul, samt möjlighet att lokalt ladda valfri bild eller video.

## Så provar du

Packa upp ZIP. Öppna `demo.html` i en modern webbläsare, med samtliga PNG-filer i samma katalog. Klicka 16:9 / 4:3 / 1:1 / 9:16, eller lägg in en bild eller video.

`demo.html` körs lokalt och kräver inget nätverk, inga JavaScript-bibliotek och ingen databas.

## Struktur

- `upper_frame.png` och `lower_frame.png` är fristående horisontella ramstycken.
- `side_left_top.png`, `side_left_middle.png`, `side_left_bottom.png` och motsvarande högra delar bygger sidorna med upprepbara mittdelar.
- `piston_*.png` är separat visuellt referensmaterial för hydrauliken.
- `gear_west.png` och `gear_east.png` har separata rotationscentrum i bildens mitt. 
- Kristaller, runstavar och emblem kan animeras självständigt.

## Teknik / nästa utvecklingssteg

1. Bygg bildvisarens inre öppning som en dynamisk DOM-container som läser `naturalWidth/naturalHeight` för bilder och `videoWidth/videoHeight` för video.
2. Applicera `object-fit:contain` och bibehåll maximal tillgänglig viewportyta. Om höjden behöver begränsas i mobilvisning ska *hela konstruktionen* skalas proportionerligt, inte det visade mediet förvrängas.
3. Flytta nedre ramen via CSS transition, håll överdelen förankrad och låt de modulära sidorna fylla mellanrummet.
4. Rotera kugghjulen endast under övergången. Placera kolvars övre och nedre fästen på var sin rörlig del och låt metallstaven förlängas bakom dem.
5. I produktionsversion: finslipa skarvar, undvik dubbla kugghjul under rotation och kontrollera anslutningspunkterna vid flera höjder. Fastställ godkänd färgstandard innan publicering.

## Kvalitetsanmärkning

Detta är **verkliga frilagda PNG-filer** framtagna ur en bildgenererad spriteatlas, men de är **inte 3D-original, SVG-vektorer eller äkta CAD-geometri**. Sidostyckenas mittmönster är tilade; de finmekaniska delarna behöver slutlig optisk passning före integrering. Den fristående demo-prototypen är avsedd för designgranskning, inte som en redan publicerad appfunktion.
